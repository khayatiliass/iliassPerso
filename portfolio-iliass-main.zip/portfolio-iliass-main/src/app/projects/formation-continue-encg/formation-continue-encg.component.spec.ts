import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FormationContinueENCGComponent } from './formation-continue-encg.component';

describe('FormationContinueENCGComponent', () => {
  let component: FormationContinueENCGComponent;
  let fixture: ComponentFixture<FormationContinueENCGComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormationContinueENCGComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FormationContinueENCGComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
