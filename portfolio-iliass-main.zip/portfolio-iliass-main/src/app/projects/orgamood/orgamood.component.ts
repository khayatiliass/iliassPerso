import { Component } from '@angular/core';
import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-orgamood',
  imports: [RouterModule], 
  standalone: true,
  templateUrl: './orgamood.component.html',
  styleUrl: './orgamood.component.css'
})
export class OrgamoodComponent {

  constructor(private router: Router) {}

  goBack() {
    this.router.navigate(['/']).then(() => {
      // Give the page a moment to load the content
      setTimeout(() => {
        const section = document.getElementById('projects');
        if (section) {
          section.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    });
  }
  

  
}
