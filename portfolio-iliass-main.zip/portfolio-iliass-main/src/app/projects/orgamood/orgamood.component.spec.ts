import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OrgamoodComponent } from './orgamood.component';

describe('OrgamoodComponent', () => {
  let component: OrgamoodComponent;
  let fixture: ComponentFixture<OrgamoodComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [OrgamoodComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(OrgamoodComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
