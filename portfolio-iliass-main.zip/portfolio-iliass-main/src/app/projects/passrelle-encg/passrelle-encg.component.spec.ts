import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PassrelleENCGComponent } from './passrelle-encg.component';

describe('PassrelleENCGComponent', () => {
  let component: PassrelleENCGComponent;
  let fixture: ComponentFixture<PassrelleENCGComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PassrelleENCGComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PassrelleENCGComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
