import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-passrelle-encg',
  imports: [],
  templateUrl: './passrelle-encg.component.html',
  styleUrl: './passrelle-encg.component.css'
})
export class PassrelleENCGComponent {
  constructor(private router: Router) {}

 
  goBack() {
    this.router.navigate(['/']).then(() => {
      // Give the page a moment to load the content
      setTimeout(() => {
        const section = document.getElementById('projects');
        if (section) {
          section.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }, 100);
    });
  }
  
}
