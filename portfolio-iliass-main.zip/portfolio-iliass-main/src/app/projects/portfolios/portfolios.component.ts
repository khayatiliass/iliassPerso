import { Component } from '@angular/core';

@Component({
  selector: 'app-portfolios',
  imports: [],
  templateUrl: './portfolios.component.html',
  styleUrl: './portfolios.component.css'
})
export class PortfoliosComponent {

}
