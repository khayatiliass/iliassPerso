import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CpgeTangerComponent } from './cpge-tanger.component';

describe('CpgeTangerComponent', () => {
  let component: CpgeTangerComponent;
  let fixture: ComponentFixture<CpgeTangerComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CpgeTangerComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CpgeTangerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
