import { Component } from '@angular/core';

@Component({
  selector: 'app-cpge-tanger',
  imports: [],
  templateUrl: './cpge-tanger.component.html',
  styleUrl: './cpge-tanger.component.css'
})
export class CpgeTangerComponent {

}
