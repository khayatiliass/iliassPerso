// app.routes.ts
import { Routes } from '@angular/router';
import { AppComponent } from './app.component';

import { OrgamoodComponent } from './projects/orgamood/orgamood.component';
import { HomeComponent } from './home/home.component';
import { PassrelleENCGComponent } from './projects/passrelle-encg/passrelle-encg.component';
import { FormationContinueENCGComponent } from './projects/formation-continue-encg/formation-continue-encg.component';

export const routes: Routes = [
  { path: '', component: HomeComponent }, // optional
  { path: 'orgamood', component: OrgamoodComponent },
  { path: 'passrelle', component: PassrelleENCGComponent },
  { path: 'formationContinue', component: FormationContinueENCGComponent },

];
