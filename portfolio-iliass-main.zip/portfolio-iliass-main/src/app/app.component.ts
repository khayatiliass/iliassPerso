import { CommonModule } from '@angular/common';
import { Component, ViewChild, ElementRef, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import emailjs from 'emailjs-com';

import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {


  projects = [
    {
      name: 'E-commerce Order Management Platform - SOPHAX',
      description: 'Complete e-commerce management solution with Angular + Tailwind CSS frontend and Spring Boot backend. Features real-time WooCommerce synchronization, Keycloak authentication (OAuth2/JWT), automated shipping tracking, and comprehensive admin dashboard. Deployed using Docker with GitLab CI/CD pipelines.',
      technologies: 'Angular, Spring Boot, Keycloak, WooCommerce API, Docker, GitLab CI/CD',
      liveDemo: '#',
      github: '#',
      imageText: 'E-commerce Platform'
    },
    {
      name: 'Academic Bridge Application System - ENCG Tanger',
      description: 'Digital platform for managing semester bridge applications (S5/S7) with automated candidate validation, administrative tracking, and document management. Streamlined the entire application process from submission to approval.',
      technologies: 'Laravel, MySQL, JavaScript, HTML/CSS, Git , GitHub',
      liveDemo: '#',
      github: '#',
      imageText: 'Academic Platform'
    },
    {
      name: 'Continuous Training Management System - ENCG Tanger',
      description: 'Comprehensive platform for managing continuing education programs with participant registration, automated list generation, session tracking, and integrated payment processing. Reduced administrative workload by 60%.',
      technologies: 'Laravel, MySQL, JavaScript, HTML/CSS, Git, GitHub', 
      liveDemo: '#',
      github: '#',
      imageText: 'Academic Platform'
    },
    {
      name: 'Perssonal Website - Portfolio',
      description: 'personal website to ...',
      technologies: 'Angular,HTML/CSS , Typesript ,  Gitlab , Git , CI/CD , EmailJs',
      liveDemo: '#',
      github: '#',
      imageText: 'Academic Platform'
    },

  ];

  scrollToSection(event: Event, sectionId: string) {
    event.preventDefault();
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  contact = {
    name: '',
    email: '',
    message: ''
  };
  onSubmit() {
    const templateParams = {
      name: this.contact.name,
      email: this.contact.email,
      message: this.contact.message,
    };
  

    emailjs.send(
      'service_h3mjybu',        // Service ID
      'template_o1fo9n9',       // Template ID
      templateParams,
      'chEnGSII27_4hlfO0'    
    )
    .then(() => {
      alert('✅ Message sent successfully! , Thank you');
      this.contact = { name: '', email: '', message: '' };
    })
    .catch((error) => {
      alert('❌ Failed to send message . Try again Later or use one of my contact options');
      console.error('EmailJS Error:', error);
    });
  }

  skillsList = [
    {
      icon: '💻',
      title: 'Langages de Programmation',
      description: 'Java, C/C++, C#, JavaScript',
    },
    {
      icon: '🖥️',
      title: 'Développement Web & Frameworks',
      description: 'Angular, Spring Boot, Laravel, Tailwind CSS, Bootstrap, HTML/CSS',
    },
    {
      icon: '🗄️',
      title: 'Bases de Données',
      description: 'MySQL, PostgreSQL, Oracle',
    },
    {
      icon: '🔒',
      title: 'Sécurité des Applications',
      description: 'OAuth2, JWT, Keycloak, RBAC, chiffrement des données, bonnes pratiques OWASP',
    },
    {
      icon: '🚀',
      title: 'DevOps & Outils',
      description: 'Git, GitHub, GitLab, Docker, Intégration & Livraison continues (CI/CD)',
    },
    {
      icon: '🏗️',
      title: 'Architecture & Conception Logicielle',
      description: 'POO, Design Patterns, Monolithique, MVC, Microservices, UML',
    },
    {
      icon: '📋',
      title: 'Méthodologies de Travail',
      description: 'Scrum, Kanban, Méthodes Agiles',
    },
  ];
  
  

  showAllSkills = false;

  toggleSkills() {
    this.showAllSkills = !this.showAllSkills;
  }


// modal orgamood ....


IsOrgamoodModelOpen : Boolean = false; 


ToggleOrgamood() {
  this.IsOrgamoodModelOpen = !this.IsOrgamoodModelOpen;
}






private router = inject(Router);

goToorgamood() {
  this.router.navigate(['/orgamood']);
}




}