
import { CommonModule } from '@angular/common';
import { Component, ViewChild, ElementRef, inject, HostListener } from '@angular/core';
import { FormsModule } from '@angular/forms';
import emailjs from 'emailjs-com';

import { Router, RouterModule } from '@angular/router';

@Component({
  selector: 'home-root',
  standalone: true,
  
  imports: [CommonModule,FormsModule,RouterModule],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {

  scrollToSection(event: Event, sectionId: string) {
    event.preventDefault();
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  }

  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  contact = {
    name: '',
    email: '',
    message: ''
  };

isSuccessModalOpen = false;
isErrorModalOpen = false;
isSending = false;

// Header state
isMobileMenuOpen = false;
isScrolled = false;

@HostListener('window:scroll')
onWindowScroll() {
  this.isScrolled = window.scrollY > 10;
}

toggleMobileMenu() {
  this.isMobileMenuOpen = !this.isMobileMenuOpen;
}

onNavClick(event: Event, sectionId: string) {
  this.scrollToSection(event, sectionId);
  this.isMobileMenuOpen = false;
}

onSubmit() {

  this.isSending = true;
  
  const templateParams = {
    name: this.contact.name,
    email: this.contact.email,
    message: this.contact.message,
  };

  emailjs.send(
    'service_h3mjybu',
    'template_o1fo9n9',
    templateParams,
    'chEnGSII27_4hlfO0'
  )
  .then(() => {
    this.isSending = false;
    this.isSuccessModalOpen = true;
    this.contact = { name: '', email: '', message: '' };
  })
  .catch((error) => {
    this.isSending = false;
    this.isErrorModalOpen = true;
    console.error('EmailJS Error:', error);
  });
}




  skillsList = [
    {
      icon: '💻',
      title: 'Langages de Programmation',
      description: 'Java, C/C++, C#, PHP, JavaScript',
    },
    {
      icon: '🖥️',
      title: 'Développement Web & Frameworks',
      description: 'Angular, Spring Boot, Laravel, Tailwind CSS, Bootstrap, HTML/CSS, Express, NestJS',
    },
    {
      icon: '🗄️',
      title: 'Bases de Données',
      description: 'MySQL, PostgreSQL, Oracle',
    },
    {
      icon: '🔒',
      title: 'Sécurité des Applications',
      description: 'OAuth2, JWT, Keycloak, RBAC, chiffrement des données, bonnes pratiques OWASP',
    },
    {
      icon: '🚀',
      title: 'DevOps & Outils',
      description: 'Git, GitHub, GitLab, Docker, Intégration & Livraison continues (CI/CD)',
    },
    {
      icon: '🤖',
      title: 'Vibe Coding & Outils IA',
      description: 'Prompt IA, Cursor, GitHub Copilot',
    },
    {
      icon: '🏗️',
      title: 'Architecture & Conception Logicielle',
      description: 'POO, Design Patterns, Monolithique, MVC, Microservices, UML',
    },
    {
      icon: '📋',
      title: 'Méthodologies de Travail',
      description: 'Scrum, Kanban, Méthodes Agiles',
    },
  ];
  
  

  showAllSkills = false;

  toggleSkills() {
    this.showAllSkills = !this.showAllSkills;
  }


// modal orgamood ....


IsOrgamoodModelOpen : Boolean = false; 


ToggleOrgamood() {
  this.IsOrgamoodModelOpen = !this.IsOrgamoodModelOpen;
}






private router = inject(Router);

goToorgamood() {
  this.router.navigate(['/orgamood']).then(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });;
}

goTopassrelle(){
  this.router.navigate(['/passrelle']).then(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}


goToformationContinue() {
  this.router.navigate(['/formationContinue']).then(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

goToShowMe() {
  window.open('https://showme-e7d4e2.gitlab.io/', '_blank');
}
}